// import React from 'react'

export default function FindFreelancers() {
  return <div>Find Freelancers</div>;
}
