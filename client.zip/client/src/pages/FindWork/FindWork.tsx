import React from 'react'

export default function FindWork() {
  return (
    <div>
      Find Work
    </div>
  )
}
