import React from 'react'

export default function PostProject() {
  return (
    <div>
      Post Project
    </div>
  )
}
